<script setup lang="ts">
import PendingRuns from "../components/PendingRuns.vue";
import { useQuery, useQueryClient } from "@tanstack/vue-query";
import { useRouter } from "vue-router";
import { useSession } from "./session";
import { client, unwrap } from "../api/client";
const session = useSession(),
  router = useRouter(),
  cache = useQueryClient();
const cap = useQuery({
  queryKey: ["capabilities"],
  queryFn: async () => unwrap(await client.GET("/api/v1/capabilities")),
});
async function logout() {
  await session.logout();
  cache.clear();
  await router.push("/login");
}
</script>
<template>
  <div class="shell" :class="{ anonymous: !session.user }">
    <aside v-if="session.user">
      <RouterLink class="brand" to="/jobs"
        ><span class="brand-mark">O</span>OfferPilot</RouterLink
      >
      <p class="aside-note">每一步，都有依据。</p>
      <nav>
        <RouterLink to="/today">今日</RouterLink
        ><RouterLink to="/discover">找岗位</RouterLink
        ><RouterLink to="/jobs">岗位库</RouterLink
        ><RouterLink to="/applications">我的申请</RouterLink
        ><RouterLink to="/study">面试准备</RouterLink
        ><RouterLink to="/profile">我的资料</RouterLink
        ><RouterLink to="/reviews">复盘与 Offer</RouterLink
        ><RouterLink v-if="session.user.is_admin" to="/operations"
          >来源与运营</RouterLink
        >
      </nav>
      <div class="account">
        <span>{{ session.user.username }}</span
        ><el-button link @click="logout">退出登录</el-button>
      </div>
    </aside>
    <div class="workspace">
      <header>
        <span>个人求职工作台</span
        ><el-tag
          :type="cap.data.value?.mode === 'live' ? 'success' : 'warning'"
          >{{
            !cap.data.value
              ? "读取模式中"
              : cap.data.value.mode === "live"
                ? "真实模式"
                : "演示数据 / 未联网"
          }}</el-tag
        >
        <el-button
          v-if="session.user"
          class="mobile-logout"
          link
          @click="logout"
          >退出登录</el-button
        >
      </header>
      <main><PendingRuns v-if="session.user" /><RouterView /></main>
      <footer>
        资料默认私有 · 外网投递与录用结果由本人确认 · Asia/Shanghai
      </footer>
    </div>
  </div>
</template>
