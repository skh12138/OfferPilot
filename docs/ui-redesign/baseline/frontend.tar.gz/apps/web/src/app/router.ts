import { createRouter, createWebHistory } from "vue-router";
import { useSession } from "./session";
export const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/reviews",
      component: () => import("../features/reviews/Reviews.vue"),
    },
    {
      path: "/operations",
      component: () => import("../features/operations/Operations.vue"),
    },
    {
      path: "/study",
      component: () => import("../features/interview/Study.vue"),
    },
    {
      path: "/study/:id",
      component: () => import("../features/interview/StudyDetail.vue"),
    },
    { path: "/today", component: () => import("../features/tasks/Today.vue") },
    {
      path: "/applications",
      component: () => import("../features/applications/Applications.vue"),
    },
    {
      path: "/applications/:id",
      component: () => import("../features/applications/ApplicationDetail.vue"),
    },
    {
      path: "/discover",
      component: () => import("../features/discovery/Discover.vue"),
    },
    { path: "/", redirect: "/today" },
    { path: "/login", component: () => import("../features/auth/Login.vue") },
    {
      path: "/profile",
      component: () => import("../features/profiles/Profile.vue"),
    },
    { path: "/jobs", component: () => import("../features/jobs/Jobs.vue") },
    {
      path: "/jobs/:id",
      component: () => import("../features/jobs/JobDetail.vue"),
    },
  ],
});
router.beforeEach(async (to) => {
  const session = useSession();
  if (to.path != "/login" && !session.user && !(await session.load()))
    return "/login";
});
