<script setup lang="ts">
import { useRoute, useRouter } from "vue-router";
import { label } from "../utils/labels";
const route = useRoute(),
  router = useRouter();
import { computed, onBeforeUnmount, watch } from "vue";
import { useQuery, useQueryClient } from "@tanstack/vue-query";
import { client, unwrap, key } from "../api/client";
import { useSession } from "../app/session";
import { useAction } from "../app/action";
const props = defineProps<{ id: string; compact?: boolean }>(),
  emit = defineEmits<{ complete: [] }>();
const session = useSession(),
  cache = useQueryClient(),
  { act, error } = useAction();
const terminal = ["succeeded", "partial", "failed", "cancelled"];
const run = useQuery({
  queryKey: computed(() => ["run", session.user?.id, props.id]),
  queryFn: async () =>
    unwrap(
      await client.GET("/api/v1/runs/{run_id}", {
        params: { path: { run_id: props.id } },
      }),
    ),
  refetchInterval: (query) =>
    terminal.includes(query.state.data?.status ?? "") ? false : 1500,
});
let source: EventSource | undefined;
let seq = 0;
watch(
  () => props.id,
  () => {
    source?.close();
    seq = 0;
    source = new EventSource(`/api/v1/runs/${props.id}/events?after=${seq}`);
    for (const kind of [
      "run_completed",
      "run_failed",
      "run_cancelled",
      "step_completed",
      "warning",
      "opportunity_ready",
    ])
      source.addEventListener(kind, (event) => {
        const n = Number((event as MessageEvent).lastEventId);
        if (n <= seq) return;
        seq = n;
        void run.refetch();
      });
  },
  { immediate: true },
);
watch(
  () => run.data.value?.status,
  (status) => {
    if (status && terminal.includes(status)) {
      source?.close();
      void cache.invalidateQueries({
        predicate: (q) => q.queryKey[0] !== "run",
      });
      emit("complete");
    }
  },
);
onBeforeUnmount(() => source?.close());
async function cancel() {
  await act(async () =>
    unwrap(
      await client.POST("/api/v1/runs/{run_id}/cancel", {
        params: { path: { run_id: props.id } },
      }),
    ),
  );
  await run.refetch();
}
async function retry() {
  await act(async () => {
    const r = unwrap(
      await client.POST("/api/v1/runs/{run_id}/retry", {
        params: { path: { run_id: props.id } },
        headers: key(),
      }),
    );
    await cache.invalidateQueries();
    await router.replace({
      query: {
        ...route.query,
        ...(r.kind === "search_organize" ? { organize: r.id } : { run: r.id }),
      },
    });
    return r;
  });
}
</script>
<template>
  <section class="panel" aria-live="polite">
    <h3>处理进度</h3>
    <el-skeleton v-if="run.isPending.value" animated /><el-alert
      v-if="run.error.value || error"
      type="error"
      :title="error || '无法读取进度'"
    /><template v-if="run.data.value"
      ><div class="toolbar">
        <el-tag>{{ label(run.data.value.status) }}</el-tag
        ><span>{{ label(run.data.value.kind) }}</span
        ><el-button
          v-if="!terminal.includes(run.data.value.status)"
          @click="cancel"
          >取消</el-button
        ><el-button
          v-if="
            ['failed', 'partial', 'cancelled'].includes(run.data.value.status)
          "
          @click="retry"
          >重试</el-button
        >
      </div>
      <p v-if="run.data.value.error_code">
        {{ run.data.value.error_code }} · 可修正资料或配置后重试
      </p>
      <p v-if="run.data.value.result.errors && !compact">
        {{ run.data.value.result.errors }}
      </p>
      <pre v-if="run.data.value.result.counts && !compact" class="evidence">{{
        run.data.value.result.counts
      }}</pre>
      <p
        v-if="compact && !terminal.includes(run.data.value.status)"
        class="muted"
      >
        正在搜索、提炼职位要求并生成机会卡片，结果将分批出现。
      </p>
      <RouterLink
        v-if="run.data.value.result.study_package_id"
        :to="`/study/${run.data.value.result.study_package_id}`"
        >打开训练包 →</RouterLink
      >
      <p class="muted">刷新或离开页面后仍可恢复。取消会保留已保存结果。</p>
      <RouterLink v-if="run.data.value.result.job_ids" to="/jobs"
        >查看岗位库 →</RouterLink
      ></template
    >
  </section>
</template>
