<script setup lang="ts">
import { computed, reactive, ref } from "vue";
import { useQuery } from "@tanstack/vue-query";
import { useRoute, useRouter } from "vue-router";
import { client, unwrap, key } from "../../api/client";
import { useSession } from "../../app/session";
import { useAction } from "../../app/action";
const session = useSession(),
  route = useRoute(),
  router = useRouter(),
  { busy, error, act } = useAction(),
  show = ref(false),
  view = ref("list");
const stage = computed({
  get: () => String(route.query.stage ?? ""),
  set: (stage) => {
    void router.replace({ query: { stage: stage || undefined } });
  },
});
const labels: Record<string, string> = {
  interested: "意向",
  preparing: "准备投递",
  submitted: "已投递",
  assessment: "考核中",
  offer: "Offer 沟通",
  onboarding: "已接受 / 入职",
  closed: "已结束",
};
const apps = useQuery({
  queryKey: computed(() => ["applications", session.user?.id, stage.value]),
  queryFn: async () =>
    unwrap(
      await client.GET("/api/v1/applications", {
        params: { query: { stage: stage.value || undefined, limit: 100 } },
      }),
    ),
});
const draft = reactive({
  title: "",
  company: "",
  job_url: "",
  apply_url: "",
  progress_url: "",
  navigation_hint: "",
});
async function create() {
  await act(async () => {
    const app = unwrap(
      await client.POST("/api/v1/applications", {
        body: {
          ...draft,
          allow_reapply: false,
          job_url: draft.job_url || null,
          apply_url: draft.apply_url || null,
          progress_url: draft.progress_url || null,
        },
        headers: key(),
      }),
    );
    await router.push("/applications/" + app.id);
  });
}
</script>
<template>
  <h1>我的申请</h1>
  <p class="subtitle">每次真实申请一份档案。下一步与历史材料，随时可回查。</p>
  <div class="toolbar">
    <el-select
      v-model="stage"
      placeholder="全部阶段"
      clearable
      style="width: 180px"
      ><el-option
        v-for="(label, value) in labels"
        :key="value"
        :label="label"
        :value="value" /></el-select
    ><el-radio-group v-model="view"
      ><el-radio-button value="list">列表</el-radio-button
      ><el-radio-button value="board">看板</el-radio-button></el-radio-group
    ><el-button type="primary" @click="show = true"
      >补录申请 / 已有面试</el-button
    >
  </div>
  <el-alert v-if="error" type="error" :title="error" /><el-skeleton
    v-if="apps.isPending.value"
    animated
  /><el-alert
    v-if="apps.error.value"
    title="加载失败，请重试"
    type="error"
    @click="apps.refetch()"
  />
  <p
    v-if="!apps.isPending.value && !apps.data.value?.items.length"
    class="panel empty"
  >
    还没有申请。可以从岗位加入，也可以直接补录已有面试。
  </p>
  <div :class="view === 'board' ? 'grid' : 'stack'">
    <article v-for="app in apps.data.value?.items" :key="app.id" class="card">
      <div class="toolbar" style="margin-top: 0">
        <el-tag>{{ labels[app.stage] }}</el-tag
        ><span class="muted">{{
          app.company_status_raw || "公司状态未记录"
        }}</span>
      </div>
      <h2>
        <RouterLink :to="'/applications/' + app.id"
          >{{ app.company }} · {{ app.title }}</RouterLink
        >
      </h2>
      <p>
        最后查看：{{
          app.last_checked_at
            ? new Date(app.last_checked_at).toLocaleString("zh-CN")
            : "尚未确认查看"
        }}
      </p>
      <p class="muted">打开外链不会改变状态，实际提交后请回来记录。</p>
    </article>
  </div>
  <el-dialog v-model="show" title="补录申请"
    ><el-form label-position="top"
      ><el-form-item label="岗位"
        ><el-input v-model="draft.title" aria-label="申请岗位" /></el-form-item
      ><el-form-item label="公司"
        ><el-input
          v-model="draft.company"
          aria-label="申请公司" /></el-form-item
      ><el-form-item label="岗位链接（可空）"
        ><el-input v-model="draft.job_url" /></el-form-item
      ><el-form-item label="投递入口（可空）"
        ><el-input v-model="draft.apply_url" /></el-form-item
      ><el-form-item label="进度入口（可空）"
        ><el-input v-model="draft.progress_url" /></el-form-item
      ><el-button
        type="primary"
        :loading="busy"
        :disabled="!draft.title || !draft.company"
        @click="create"
        >创建申请档案</el-button
      ></el-form
    ></el-dialog
  >
</template>
