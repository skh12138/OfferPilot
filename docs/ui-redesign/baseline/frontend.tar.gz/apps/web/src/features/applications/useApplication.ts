import { computed, type Ref } from "vue";
import { useQuery, useQueryClient } from "@tanstack/vue-query";
import { client, unwrap } from "../../api/client";
import { useSession } from "../../app/session";
export function useApplication(id: Ref<string>) {
  const session = useSession(),
    cache = useQueryClient();
  const app = useQuery({
    queryKey: computed(() => ["application", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/applications/{app_id}", {
          params: { path: { app_id: id.value } },
        }),
      ),
  });
  const rounds = useQuery({
    queryKey: computed(() => ["rounds", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/applications/{app_id}/rounds", {
          params: { path: { app_id: id.value } },
        }),
      ),
  });
  const events = useQuery({
    queryKey: computed(() => ["events", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/applications/{app_id}/events", {
          params: { path: { app_id: id.value } },
        }),
      ),
  });
  const submissions = useQuery({
    queryKey: computed(() => ["submissions", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/applications/{app_id}/submissions", {
          params: { path: { app_id: id.value } },
        }),
      ),
  });
  const bundles = useQuery({
    queryKey: computed(() => ["bundles", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/applications/{app_id}/preparation-bundles", {
          params: { path: { app_id: id.value } },
        }),
      ),
  });
  const profile = useQuery({
    queryKey: ["profile", session.user?.id],
    queryFn: async () => unwrap(await client.GET("/api/v1/profiles/current")),
  });
  const tasks = useQuery({
    queryKey: computed(() => ["tasks", session.user?.id, id.value]),
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/tasks", {
          params: { query: { application_id: id.value, limit: 100 } },
        }),
      ),
  });
  const jobs = useQuery({
    queryKey: ["jobs", session.user?.id],
    queryFn: async () =>
      unwrap(
        await client.GET("/api/v1/jobs", { params: { query: { limit: 100 } } }),
      ),
  });
  async function refresh() {
    await cache.invalidateQueries({
      predicate: (q) => q.queryKey[0] !== "run",
    });
  }
  return {
    app,
    rounds,
    events,
    submissions,
    bundles,
    profile,
    tasks,
    jobs,
    refresh,
  };
}
