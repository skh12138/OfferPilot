import { computed, reactive, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { client, unwrap, key } from "../../api/client";
import { useAction } from "../../app/action";
import { useApplication } from "./useApplication";
import type { components } from "../../api/schema";

export function useApplicationActions() {
  const route = useRoute(),
    router = useRouter(),
    id = computed(() => String(route.params.id));
  const {
      app,
      rounds,
      events,
      submissions,
      bundles,
      profile,
      tasks,
      jobs,
      refresh,
    } = useApplication(id),
    { busy, error, act } = useAction();
  const runId = computed({
    get: () => String(route.query.run ?? ""),
    set: (run) => {
      void router.replace({ query: { ...route.query, run } });
    },
  });
  const basisJobId = ref<string | null>(null);
  const dialog = ref(""),
    profileId = ref<string | null>(null),
    missing = ref(true),
    confirmed = ref(false),
    submittedAt = ref(new Date().toISOString()),
    observed = ref(""),
    target = ref<components["schemas"]["EventInput"]["to_stage"]>("preparing"),
    eventType =
      ref<components["schemas"]["EventInput"]["event_type"]>("advance"),
    reason = ref(""),
    taskAction = ref<"keep" | "cancel" | "detach">("keep");
  const links = reactive({
    job_url: "",
    apply_url: "",
    progress_url: "",
    navigation_hint: "",
  });
  watch(
    () => app.data.value,
    (row) => {
      if (row) {
        links.job_url = row.job_url ?? "";
        links.apply_url = row.apply_url ?? "";
        links.progress_url = row.progress_url ?? "";
        links.navigation_hint = row.navigation_hint;
      }
    },
  );
  const round = reactive<components["schemas"]["RoundInput"]>({
      type: "technical",
      name: "技术一面",
      order: 1,
      status: "scheduled",
      planned_at: null,
      actual_at: null,
      deadline_at: null,
      location: "",
      reminders_enabled: false,
    }),
    editingRound = ref<components["schemas"]["RoundDTO"]>();
  async function submit() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      unwrap(
        await client.POST("/api/v1/applications/{app_id}/submissions", {
          params: { path: { app_id: id.value } },
          headers: key(),
          body: {
            expected_revision: row.revision,
            actual_submission_confirmed: confirmed.value,
            submitted_at: new Date(submittedAt.value).toISOString(),
            channel: "本人官网提交",
            job_version_id: row.job_version_id,
            profile_version_id: profileId.value,
            missing_materials: missing.value,
          },
        }),
      );
      dialog.value = "";
      await refresh();
    });
  }
  async function check() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      unwrap(
        await client.POST("/api/v1/applications/{app_id}/progress-checks", {
          params: { path: { app_id: id.value } },
          body: {
            expected_revision: row.revision,
            checked_at: new Date().toISOString(),
            observed_status: observed.value,
            changed: false,
            user_confirmed: true,
            company_status_kind: row.company_status_kind,
          },
        }),
      );
      await refresh();
    });
  }
  async function stage() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      unwrap(
        await client.POST("/api/v1/applications/{app_id}/events", {
          params: { path: { app_id: id.value } },
          headers: key(),
          body: {
            expected_revision: row.revision,
            event_type: eventType.value,
            to_stage: target.value,
            reason: reason.value,
            source: "本人记录",
            happened_at: new Date().toISOString(),
            close_reason: target.value === "closed" ? reason.value : null,
            task_action: taskAction.value,
          },
        }),
      );
      dialog.value = "";
      await refresh();
    });
  }
  async function saveRound() {
    await act(async () => {
      if (editingRound.value) {
        unwrap(
          await client.PATCH("/api/v1/rounds/{round_id}", {
            params: { path: { round_id: editingRound.value.id } },
            body: {
              ...round,
              expected_revision: editingRound.value.revision,
              reason: reason.value || "本人改期或更新结果",
            },
          }),
        );
      } else {
        unwrap(
          await client.POST("/api/v1/applications/{app_id}/rounds", {
            params: { path: { app_id: id.value } },
            body: round,
          }),
        );
      }
      dialog.value = "";
      await refresh();
    });
  }
  function editRound(row: components["schemas"]["RoundDTO"]) {
    editingRound.value = row;
    Object.assign(round, {
      type: row.type,
      name: row.name,
      order: row.order,
      status: row.status,
      planned_at: row.planned_at,
      actual_at: row.actual_at,
      deadline_at: row.deadline_at,
      location: row.location,
      reminders_enabled: row.reminders_enabled,
    });
    dialog.value = "round";
  }
  async function saveLinks() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      unwrap(
        await client.PATCH("/api/v1/applications/{app_id}", {
          params: { path: { app_id: id.value } },
          body: {
            expected_revision: row.revision,
            ...links,
            job_url: links.job_url || null,
            apply_url: links.apply_url || null,
            progress_url: links.progress_url || null,
            company_status_raw: row.company_status_raw,
            company_status_kind: row.company_status_kind,
          },
        }),
      );
      await refresh();
    });
  }
  async function prepare() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      const run = unwrap(
        await client.POST("/api/v1/applications/{app_id}/preparation-runs", {
          params: { path: { app_id: id.value } },
          body: { expected_revision: row.revision },
          headers: key(),
        }),
      );
      runId.value = run.id;
    });
  }
  async function changeBasis() {
    const row = app.data.value;
    if (!row) return;
    await act(async () => {
      unwrap(
        await client.POST("/api/v1/applications/{app_id}/preparation-basis", {
          params: { path: { app_id: id.value } },
          body: {
            expected_revision: row.revision,
            job_version_id: basisJobId.value ?? row.job_version_id,
            profile_version_id: profileId.value,
            reason: "本人显式切换准备资料",
          },
        }),
      );
      await refresh();
    });
  }

  return {
    id,
    app,
    rounds,
    events,
    submissions,
    bundles,
    profile,
    tasks,
    jobs,
    refresh,
    busy,
    error,
    runId,
    basisJobId,
    dialog,
    profileId,
    missing,
    confirmed,
    submittedAt,
    observed,
    target,
    eventType,
    reason,
    taskAction,
    links,
    round,
    editingRound,
    submit,
    check,
    stage,
    saveRound,
    editRound,
    saveLinks,
    prepare,
    changeBasis,
  };
}
