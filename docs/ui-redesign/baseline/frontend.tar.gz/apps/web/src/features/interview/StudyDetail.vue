<script setup lang="ts">
import StudyEditor from "./StudyEditor.vue";
import { computed } from "vue";
import { useRoute } from "vue-router";
import { useQuery } from "@tanstack/vue-query";
import { client, unwrap, key } from "../../api/client";
import { useSession } from "../../app/session";
import { useAction } from "../../app/action";
import QuestionPractice from "./QuestionPractice.vue";
const route = useRoute(),
  id = computed(() => String(route.params.id)),
  session = useSession(),
  { busy, error, act } = useAction();
const study = useQuery({
  queryKey: computed(() => ["study", session.user?.id, id.value]),
  queryFn: async () =>
    unwrap(
      await client.GET("/api/v1/study-packages/{package_id}", {
        params: { path: { package_id: id.value } },
      }),
    ),
});
const sources = useQuery({
  queryKey: ["interview-sources", session.user?.id],
  queryFn: async () => unwrap(await client.GET("/api/v1/interview-sources")),
});
async function adopt() {
  const pack = study.data.value,
    version = pack?.current;
  if (!pack || !version) return;
  await act(async () => {
    unwrap(
      await client.POST("/api/v1/study-packages/{package_id}/adopt", {
        params: { path: { package_id: id.value } },
        headers: key(),
        body: {
          expected_revision: pack.revision,
          version_id: version.id,
          payload_hash: version.payload_hash,
          basis_revision: version.basis_revision,
        },
      }),
    );
    await study.refetch();
  });
}
</script>
<template>
  <RouterLink to="/study">← 面试准备</RouterLink>
  <h1 style="margin-top: 20px">岗位训练包</h1>
  <el-alert
    v-if="error || study.error.value"
    :title="error || '读取失败'"
    type="error"
  /><el-skeleton v-if="study.isPending.value" animated /><template
    v-if="study.data.value?.current"
    ><section class="panel">
      <h2>能力地图</h2>
      <StudyEditor
        v-if="study.data.value"
        :study="study.data.value"
        @saved="study.refetch()"
      />
      <p v-for="topic in study.data.value.current.topics" :key="topic.topic">
        <strong>{{ topic.topic }}</strong> · {{ topic.reason }}
      </p>
      <el-alert
        v-for="limit in study.data.value.current.limitations"
        :key="limit"
        :title="limit"
        type="info"
        :closable="false"
      /><el-button
        type="primary"
        :loading="busy"
        :disabled="
          study.data.value.current.adopted || study.data.value.current.deleted
        "
        @click="adopt"
        >{{
          study.data.value.current.adopted
            ? "题单已采用"
            : "采用题单并建立复习任务"
        }}</el-button
      >
      <p class="muted">生成后不会自动创建正式任务；采用后也不代表掌握。</p>
    </section>
    <QuestionPractice
      v-for="question in study.data.value.current.questions"
      :key="question.id"
      :question="question"
      :sources="sources.data.value?.items ?? []"
  /></template>
</template>
