<script setup lang="ts">
import DuplicatePanel from "./DuplicatePanel.vue";
import { label } from "../../utils/labels";
import { computed, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useQuery } from "@tanstack/vue-query";
import { client, unwrap, key } from "../../api/client";
import { useAction } from "../../app/action";
import { useSession } from "../../app/session";
import RunStatus from "../../components/RunStatus.vue";
import type { components } from "../../api/schema";
const route = useRoute(),
  router = useRouter(),
  session = useSession(),
  { busy, error, act } = useAction();
const q = computed({
  get: () => String(route.query.q ?? ""),
  set: (value) => {
    void router.replace({
      query: { ...route.query, q: value || undefined, cursor: undefined },
    });
  },
});
function filter(name: string) {
  return computed({
    get: () => String(route.query[name] ?? ""),
    set: (value: string) => {
      void router.replace({
        query: {
          ...route.query,
          [name]: value || undefined,
          cursor: undefined,
        },
      });
    },
  });
}
const preference = filter("preference"),
  risk = filter("risk"),
  eligibility = filter("eligibility");
const jobs = useQuery({
  queryKey: computed(() => [
    "jobs",
    session.user?.id,
    q.value,
    preference.value,
    risk.value,
    eligibility.value,
    route.query.cursor,
  ]),
  queryFn: async () =>
    unwrap(
      await client.GET("/api/v1/jobs", {
        params: {
          query: {
            q: q.value,
            preference: preference.value || undefined,
            risk: risk.value || undefined,
            eligibility: eligibility.value || undefined,
            cursor: route.query.cursor ? String(route.query.cursor) : undefined,
          },
        },
      }),
    ),
});
const text = ref(""),
  url = ref(""),
  format = ref<"text" | "csv">("text"),
  runId = computed({
    get: () => String(route.query.run ?? ""),
    set: (run) => {
      void router.replace({ query: { ...route.query, run } });
    },
  }),
  showImport = ref(false),
  selected = ref<string[]>([]),
  comparison = ref<components["schemas"]["JobDTO"][]>([]);
async function submit() {
  await act(async () => {
    const run = unwrap(
      await client.POST("/api/v1/job-imports", {
        body: {
          text: text.value,
          url: url.value || null,
          format: format.value,
        },
        headers: key(),
      }),
    );
    runId.value = run.id;
    showImport.value = false;
  });
}
async function compare() {
  await act(async () => {
    comparison.value = unwrap(
      await client.POST("/api/v1/jobs/compare", {
        body: { ids: selected.value },
      }),
    );
  });
}

async function readCsv(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    error.value = "CSV最多5MB";
    return;
  }
  format.value = "csv";
  text.value = await file.text();
}
</script>
<template>
  <h1>岗位库</h1>
  <p class="subtitle">按条件判断，回到来源核实，再决定下一步。</p>
  <div class="toolbar">
    <el-input
      v-model="q"
      placeholder="筛选岗位 / 公司 / 城市"
      aria-label="筛选岗位"
      clearable
    /><el-button @click="showImport = true">导入文本 / CSV</el-button
    ><el-button
      :disabled="!selected.length || selected.length > 4"
      @click="compare"
      >比较 {{ selected.length }} / 4</el-button
    >
  </div>
  <div class="toolbar">
    <el-select
      v-model="preference"
      aria-label="意向筛选"
      placeholder="全部意向"
      clearable
    >
      <el-option
        v-for="[value, text] in [
          ['priority', '优先'],
          ['interested', '感兴趣'],
          ['unassigned', '未设置'],
          ['paused', '暂缓'],
          ['excluded', '已排除'],
        ]"
        :key="value"
        :value="value"
        :label="text"
      />
    </el-select>
    <el-select
      v-model="eligibility"
      aria-label="资格筛选"
      placeholder="全部资格状态"
      clearable
    >
      <el-option
        v-for="[value, text] in [
          ['pass', '条件通过'],
          ['fail', '存在不符'],
          ['unknown', '仍需核实'],
        ]"
        :key="value"
        :value="value"
        :label="text"
      />
    </el-select>
    <el-select
      v-model="risk"
      aria-label="风险筛选"
      placeholder="默认隐藏高风险提示"
      clearable
    >
      <el-option
        v-for="[value, text] in [
          ['unknown', '风险未知'],
          ['no_known_flags', '暂无已知风险提示'],
          ['high_risk_flag', '查看高风险提示岗位'],
        ]"
        :key="value"
        :value="value"
        :label="text"
      />
    </el-select>
  </div>
  <el-alert v-if="error" type="error" :title="error" /><RunStatus
    v-if="runId"
    :id="runId"
    @complete="jobs.refetch()"
  /><el-skeleton v-if="jobs.isPending.value" :rows="6" animated /><el-alert
    v-else-if="jobs.error.value"
    title="岗位加载失败，点击重试"
    type="error"
    @click="jobs.refetch()"
  />
  <div v-else-if="!jobs.data.value?.items.length" class="panel empty">
    还没有岗位。先找岗位，或粘贴一份 JD 补录。
  </div>
  <DuplicatePanel @saved="jobs.refetch()" />
  <div class="grid">
    <article v-for="job in jobs.data.value?.items" :key="job.id" class="card">
      <el-checkbox
        v-model="selected"
        :value="job.id"
        :aria-label="`比较 ${job.current?.data.title}`"
        >加入比较</el-checkbox
      >
      <h2 style="margin-top: 16px">
        <RouterLink :to="`/jobs/${job.id}`">{{
          job.current?.data.title
        }}</RouterLink>
      </h2>
      <p>
        {{ job.current?.data.company }} ·
        {{ job.current?.data.cities?.join(" / ") || "城市待核实" }}
      </p>
      <div class="tags">
        <el-tag>{{
          label(job.verification?.source_status || "来源待核实")
        }}</el-tag
        ><el-tag type="info">{{
          label(job.verification?.availability_status || "有效性未知")
        }}</el-tag
        ><el-tag type="warning">{{
          label(job.verification?.risk_status || "未评估")
        }}</el-tag>
      </div>
      <p v-for="(condition, name) in job.current?.data.conditions" :key="name">
        {{ label(name ?? "待核实") }}：{{
          condition.unrestricted ? "明确不限" : (condition.value ?? "未知")
        }}
        · {{ label(condition.review_status ?? "待核实") }}
      </p>
      <p class="muted">
        缺失：{{
          job.current?.data.missing_fields?.map(label).join("、") ||
          "请查看详情证据"
        }}
      </p>
      <p class="muted">资格：{{ label(job.eligibility) }}</p>
      <p class="muted" v-for="reason in job.ranking_reasons" :key="reason">
        {{ reason.replace(job.preference, label(job.preference)) }}
      </p>
    </article>
  </div>
  <div class="toolbar">
    <el-button
      @click="router.replace({ query: { ...route.query, cursor: undefined } })"
      >第一页</el-button
    ><el-button
      :disabled="!jobs.data.value?.has_more"
      @click="
        router.replace({
          query: {
            ...route.query,
            cursor: jobs.data.value?.next_cursor ?? undefined,
          },
        })
      "
      >下一页</el-button
    >
  </div>
  <section v-if="comparison.length" class="panel">
    <h2>岗位比较</h2>
    <el-table :data="comparison"
      ><el-table-column label="岗位"
        ><template #default="scope">{{
          scope.row.current?.data.title
        }}</template></el-table-column
      ><el-table-column label="城市"
        ><template #default="scope">{{
          scope.row.current?.data.cities?.join(" / ")
        }}</template></el-table-column
      ><el-table-column label="薪资原文"
        ><template #default="scope">{{
          scope.row.current?.data.salary.raw || "待核实"
        }}</template></el-table-column
      ></el-table
    >
  </section>
  <el-dialog v-model="showImport" title="导入岗位" width="640px"
    ><el-form label-position="top"
      ><el-form-item label="导入格式"
        ><el-radio-group v-model="format"
          ><el-radio-button value="text">JD 文本</el-radio-button
          ><el-radio-button value="csv"
            >CSV（text,url 列）</el-radio-button
          ></el-radio-group
        ></el-form-item
      ><el-form-item label="CSV 文件（最多5MB / 500行）"
        ><input
          type="file"
          accept=".csv,text/csv"
          aria-label="CSV 文件"
          @change="readCsv" /></el-form-item
      ><el-form-item label="岗位正文 / CSV 内容"
        ><el-input
          v-model="text"
          type="textarea"
          :rows="10"
          aria-label="岗位正文" /></el-form-item
      ><el-form-item label="来源链接（可空）"
        ><el-input v-model="url" aria-label="岗位来源" /></el-form-item
      ><el-alert
        title="内容标为用户提供，不自动认定官方来源或已投递。"
        :closable="false"
      /><el-button
        type="primary"
        :loading="busy"
        :disabled="!text"
        @click="submit"
        >解析岗位</el-button
      ></el-form
    ></el-dialog
  >
</template>
