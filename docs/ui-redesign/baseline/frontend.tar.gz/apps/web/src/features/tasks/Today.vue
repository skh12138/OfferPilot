<script setup lang="ts">
import { reactive } from "vue";
import { useQuery } from "@tanstack/vue-query";
import { client, unwrap } from "../../api/client";
import { useSession } from "../../app/session";
import { useAction } from "../../app/action";
import TaskCard from "./TaskCard.vue";
const session = useSession(),
  { busy, error, act } = useAction();
const today = useQuery({
  queryKey: ["today", session.user?.id],
  queryFn: async () => unwrap(await client.GET("/api/v1/dashboard/today")),
});
const draft = reactive({
  title: "",
  due_date: "",
  deliverable: "",
  acceptance: "",
});
async function create() {
  await act(async () => {
    unwrap(
      await client.POST("/api/v1/tasks", {
        body: { ...draft, due_date: draft.due_date || null, kind: "other" },
      }),
    );
    draft.title = "";
    await today.refetch();
  });
}
</script>
<template>
  <h1>今天，推进一小步</h1>
  <p class="subtitle">
    关注到期事项、面试安排与待确认资料。站内提醒按 Asia/Shanghai 显示。
  </p>
  <el-alert
    v-if="error || today.error.value"
    :title="error || '读取失败，可刷新重试'"
    type="error"
  /><el-skeleton v-if="today.isPending.value" animated />
  <div class="metrics">
    <div class="metric">
      今日待办<strong>{{ today.data.value?.tasks.length ?? "—" }}</strong>
    </div>
    <div class="metric">
      未来七天<strong>{{
        today.data.value?.next_seven_days.length ?? "—"
      }}</strong>
    </div>
    <div class="metric">
      已逾期<strong>{{ today.data.value?.overdue.length ?? "—" }}</strong>
    </div>
    <div class="metric">
      待确认事实<strong>{{
        today.data.value?.pending_confirmation ?? "—"
      }}</strong>
    </div>
  </div>
  <section class="panel">
    <h2>新建待办</h2>
    <el-form label-position="top" @submit.prevent="create"
      ><div class="grid">
        <el-form-item label="下一步"
          ><el-input
            v-model="draft.title"
            aria-label="待办标题" /></el-form-item
        ><el-form-item label="截止日期（可空）"
          ><el-date-picker
            v-model="draft.due_date"
            value-format="YYYY-MM-DD" /></el-form-item
        ><el-form-item label="交付物"
          ><el-input v-model="draft.deliverable" /></el-form-item
        ><el-form-item label="完成标准"
          ><el-input v-model="draft.acceptance"
        /></el-form-item>
      </div>
      <el-button native-type="submit" :loading="busy" :disabled="!draft.title"
        >保存待办</el-button
      ></el-form
    >
  </section>
  <section v-if="today.data.value" class="panel">
    <h2>未来七天日程与回复期限</h2>
    <p v-for="round in today.data.value.rounds" :key="round.id">
      <RouterLink :to="'/applications/' + round.application_id"
        >{{ round.name }} · {{ round.planned_at }}</RouterLink
      >
    </p>
    <p v-for="offer in today.data.value.offer_deadlines" :key="offer.id">
      <RouterLink to="/reviews"
        >Offer 回复期限 · {{ offer.reply_deadline }} ·
        请本人核实和决定</RouterLink
      >
    </p>
    <p v-for="review in today.data.value.review_due" :key="review.id">
      <RouterLink to="/study"
        >复习 {{ review.topic }} · {{ review.next_date }}</RouterLink
      >
    </p>
  </section>
  <h2>今日与未排期事项</h2>
  <p v-if="!today.data.value?.tasks.length" class="panel empty">
    今天没有待办。可以安排一场练习，或查看申请进度。
  </p>
  <div class="grid">
    <TaskCard
      v-for="task in today.data.value?.tasks"
      :key="task.id"
      :task="task"
      @saved="today.refetch()"
    />
  </div>
  <h2 style="margin-top: 24px">逾期与临近</h2>
  <div class="grid">
    <TaskCard
      v-for="task in [
        ...(today.data.value?.overdue ?? []),
        ...(today.data.value?.next_seven_days ?? []),
      ]"
      :key="task.id"
      :task="task"
      @saved="today.refetch()"
    />
  </div>
</template>
