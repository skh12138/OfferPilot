import { createApp } from "vue";
import { createPinia } from "pinia";
import { VueQueryPlugin } from "@tanstack/vue-query";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import App from "./app/App.vue";
import { router } from "./app/router";
import "./styles/main.scss";
import "./styles/discovery.scss";
import { initCsrf } from "./api/client";
createApp(App)
  .use(createPinia())
  .use(VueQueryPlugin)
  .use(ElementPlus)
  .use(router)
  .mount("#app");

void initCsrf().catch((error) =>
  console.error(error instanceof Error ? error.message : "CSRF初始化失败"),
);
